const initialState = {
  username: 'login',
};
const reducer = (state = initialState, action) => {
    switch (action.type) {
      case 'LOGIN_SUCCESS':
        return {
          ...state,
          username: action.payload,
        };
      case 'LOGIN_FAILURE':
        return {
          ...state,
          username: 'Null',
        };
      default:
        return state;
    }
  };
  
  export default reducer;