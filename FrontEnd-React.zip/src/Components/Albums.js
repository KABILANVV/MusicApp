import React from 'react'
import '../styles/albums.css'
function Albums() {
  return (
  <>
    <div className='bgalbum'>
        <div className="iconComp">
            <h1>Play your preffered Album</h1>
            <div className='icon-slide'>
                <div className='align'>
                    <div><img src="https://static.qobuz.com/images/covers/ac/tk/pb6yio7latkac_600.jpg" alt="" /></div>
                    <p>Top Hits</p>
                </div>
                <div>
                    <div><img src="https://i.scdn.co/image/ab67706c0000bebb031a9d25e9a4c24c0a9474f8" alt="" /></div>
                    <p> 2023 Hits&nbsp;</p></div>
                <div>
                    <div><img src="https://i.scdn.co/image/ab67706c0000da849f3cbfb3fa1dc99e8eae92a6" alt="" /> </div><p>Top Tamil Hits&nbsp;</p></div>
              
                <div>
                    <div><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRFLZnKo8ESE3SkPQ5aaILNBiAJNND1BpoP5Q&usqp=CAU" alt="" /> </div><p>Hindi Top Hits&nbsp;</p></div>
                <div>
                    <div><img src="https://www.telugunestam.com/wp-content/uploads/2021/03/buttabomma.jpg" alt="" /> </div><p>Telugu Top Hits&nbsp;</p></div>
                <div>
                    <div><img src="https://imgcache.joox.com/music/joox/photo_my_en/toplist_300/0/a/27287bcf26c41e5c0bcc8ef1a46dbc0a.jpg" alt="" /> </div><p>Top English Songs&nbsp;</p></div>
              
            </div>
        </div>
    </div>
  
  </>
  )
}

export default Albums