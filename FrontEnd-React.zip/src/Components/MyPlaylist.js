
import axios from "axios";
import "../styles/search.css";
import React, { Component } from "react";

class SearchElement extends Component {
  state = {
    data: [],
    searchTerm: "", // New state to hold the search term
  };

  componentDidMount() {
    axios
      .get("http://localhost:8080/songs")
      .then(response => {
        this.setState({ data: response.data });
      })
      .catch(error => {
        console.log(error);
      });
  }

  // Function to handle changes in the search input
  handleSearchChange = event => {
    const { value } = event.target;
    this.setState({ searchTerm: value });
  };

  render() {
    const { data, searchTerm } = this.state;
    // Filter the recipes based on the search term
    const filteredRecipes = data.filter(user =>
      user.songname.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <>
        <br />
        <br />
        <br />
        <br />
        {/* Add the search input */}
        <div className="search-container">
          
        </div>
        <div className="showans">
          <div></div>
          {filteredRecipes.map((user, index) => (
            <div className="div" key={user.songname}>
              <div className="lab1">
                <h1 className="tabcon">{user.songname}</h1>
              </div>
              {/* <img
                src={user.imageurl}
                alt="recipe"
                width="192"
                height="262"
                style={{ borderRadius: "50%" }}
              /> */}
            </div>
          ))}
        </div>
      </>
    );
  }
}

const MyPlaylist = () => {
   
    return (
        <>
            {/* <NavBar userData={userData}/> */}
            <div className="container">
                <h1 >Your PlayList</h1>
                <article className="section">
                    {/* <SearchResults search={search} searchResults={searchResults} onAdd={doThese} />
                    <PlayList playListTracks={playListTracks} playListName={playListName} onNameChange={updatePlayListname} onRemove={removeTrack} onSave={savePlayList} /> */}
                </article>
                
      <SearchElement/>
            </div>
        </>
    )
}
export default MyPlaylist