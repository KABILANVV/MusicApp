// import React, { useState, useEffect } from 'react';

import MusicBar from './musicbar';

const MusicPlayer = () => {

  return (
    <div>
    
    <MusicBar/>
    </div>
    );
  };
  
  export default MusicPlayer;
  
  /* <ul className="list-group">
  </ul>
      {items.map((item) => (
        <li key={item.id} className="list-group-item">{item.name}</li>
      ))} */