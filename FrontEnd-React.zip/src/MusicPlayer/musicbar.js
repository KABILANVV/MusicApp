import React, { useEffect, useRef, useState } from 'react';
import axios from 'axios';
// import SearchElement from '../Home/SearchBar';
import '../styles/player.css'
// import  music from "./Songs/Hukum.mp3"
import { FaPlay, FaPause, FaForward, FaBackward } from 'react-icons/fa';

function MusicBar() {
  
  const formatTime = timeInSeconds => {
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  // const [time,setTime]=useState(0);
  const [duration, setDuration] = useState(0);
  // const [Song,setSong]=useState("");
  const [currentTime, setCurrentTime] = useState(0);
  const [songs,setSongs]=useState([]);
  const [songIndex, setSongIndex] = useState(1);
  const [isPlaying, setIsPlaying] = useState(false); 
  const [audioSrc, setAudioSrc] = useState(''); 
  const audioRef = useRef(null);
  const changeAudioSource = () => {
    // Update the audio source when the button is clicked
    setAudioSrc(songs[songIndex].url);
    
    setDuration(audioRef.current.duration)
    if(!isPlaying){
      audioRef.current.play()
    }
    const songInfo = document.getElementById('song-info');
        if (songInfo) {
          songInfo.textContent = `${songs[songIndex].songname} \n- ${songs[songIndex].songdesc}`;
        }
      };
      useEffect(() => {
        setCurrentTime(audioRef.current.currentTime)
        axios
        .get('http://localhost:8080/songs')
      .then(response => {
        const musicData= response.data;
        // alert(response.data.url)
        // Assuming the first song in the array is selected
        const selectedSong = musicData[0];
        setSongs(response.data)
        const audioPlayer = document.getElementById('audio-player');
        const duration = audioPlayer.duration;
        setDuration(duration)
        setAudioSrc(selectedSong.url)
        setIsPlaying(true);
        // setSongs(musicData)

        // Update the audio source
        // const audioPlayer = document.getElementById('audio-player');
        // audioPlayer.src = selectedSong.url;
        // setSong(selectedSong.url)
        // setAudioSource(selectedSong.url);
        // Update the song info display
        const songInfo = document.getElementById('song-info');
        if (songInfo) {
          songInfo.textContent = `${selectedSong.songname} - ${selectedSong.songdesc}`;
        }
        // setSonginfo(selectedSong)
        
        // Play the audio
        // audioPlayer.play();
      })
      .catch(error => {
        alert(error);
        console.error('Error fetching music:', error);
      });
    }, []);
    
    function toggleAudio() {
      if (isPlaying) {
        audioRef.current.play();
      } else {
        audioRef.current.pause();
    }
    setIsPlaying(!isPlaying);
  } 
  function prevSong() {
    setSongIndex((prevIndex) => (prevIndex === 0 ? songs.length - 1 : prevIndex - 1));
    changeAudioSource()
    const audioPlayer = document.getElementById('audio-player');
        const duration = audioPlayer.duration;
        setDuration(duration)
    setIsPlaying(true);
  }
  
  function nextSong() {
    setSongIndex((prevIndex) => (prevIndex === songs.length - 1 ? 0 : prevIndex + 1));
    changeAudioSource()
    setIsPlaying(true);
    const audioPlayer = document.getElementById('audio-player');
    const duration = audioPlayer.duration;
    setDuration(duration)
  }
  const onTimeUpdate = () => {
    setCurrentTime(audioRef.current.currentTime);
  };
  const handleTimeUpdate = (event) => {
    const audioPlayer = document.getElementById('audio-player');
    const currentTime = audioPlayer.currentTime;
    
    setCurrentTime(currentTime)
    const duration = audioPlayer.duration;
    setDuration(duration)
    const progressPercentage = (currentTime / duration) * 100;
    const progress = document.getElementById('progress');
    progress.style.width = `${progressPercentage}%`;
  };

  const handleVolumeChange = event => {
    const audioPlayer = document.getElementById('audio-player');
    const volume = event.target.value;
    audioPlayer.volume = volume;
  };
  const onProgressBarChange = (e) => {
    const newTime = e.target.value;
    audioRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  };
  
  useEffect(() => {
    const audioPlayer = document.getElementById('audio-player');
    audioPlayer.addEventListener('timeupdate', handleTimeUpdate);

    return () => {
      audioPlayer.removeEventListener('timeupdate', handleTimeUpdate);
    };
  }, []);

  return (
    <div>
      <div className="music-player">

        <audio id="audio-player" ref={audioRef} onTimeUpdate={onTimeUpdate} onChange={onProgressBarChange} src={audioSrc} >
        </audio>
        <div className="progress-bar">
          <div id="progress" className="progress" ></div>
        </div>
        <div className="time-display">
        <span>{formatTime(currentTime)}</span>
        <span> / </span>
        <span>{formatTime(duration)}</span>
      </div>
        <div className="fancy-gradient-text" id="song-info"></div>
      
      <input
        type="range"
        id="volume-control"
        min="0"
        max="1"
        step="0.1"
        onChange={handleVolumeChange}
      />
      <div>

      <button id="prev" className="action" onClick={prevSong}>
          <FaBackward style={{fontSize:"20px",position:'relative'}}/>
          </button>
          <button id="play" className="action" onClick={toggleAudio}>
          {isPlaying ? <FaPlay style={{fontSize:"33px"}}/>:<FaPause style={{fontSize:"33px"}}/>}
          </button>
          <button id="next" className="action" onClick={nextSong}>
          <FaForward style={{fontSize:"20px",position:'relative'}}/>
          </button>
      </div>
      </div>
      {/* {songs.map((item) => (
        <div>{item.url}</div>
      ))}  */}
      {/* <SearchElement/> */}
    </div>
  );
}

export default MusicBar;
