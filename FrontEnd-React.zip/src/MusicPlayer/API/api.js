const express = require('express');
const app = express();
  
  app.get('/api/music/:id', (req, res) => {
    const musicId = req.params.id;
    // Logic to fetch a specific music track by ID and send the response
  });
  app.get('/api/music', (req, res) => {
    // Logic to fetch music data
    const musicData = [
      { title: 'Song 1', artist: 'Artist 1', url: 'https://music.apple.com/in/album/naa-ready-from-leo/1693819969?i=1693819972' },
      { title: 'Song 2', artist: 'Artist 2', url: 'https://music.apple.com/in/album/naa-ready-from-leo/1693819969?i=1693819972' },
    ];
  
    // Send the music data as the response
    res.json(musicData);
  });
  const PORT = process.env.PORT || 3002;


  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });