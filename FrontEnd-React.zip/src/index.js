import React from 'react';
import ReactDOM from 'react-dom/client';
// import App from './App';
// import Login from './User/Login';
// import Forms from './User/form';
// import Home from './Home/Home';
// import Sidebar from './Home/SideBar';
import reportWebVitals from './reportWebVitals';
import Routing from './Routing';
// import SearchBar from './Components/SearchBar';
import { Provider } from 'react-redux';
import store from './Store/Store';
import { BrowserRouter } from 'react-router-dom';
// import MusicBar from './MusicPlayer/musicbar';



const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  
  <Provider store={store}>
  <BrowserRouter>
        <Routing/>
  </BrowserRouter>
  </Provider>  
);


// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
