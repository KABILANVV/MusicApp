import Container from 'react-bootstrap/Container';
import React, { Component } from 'react';
import Navbar from 'react-bootstrap/Navbar';
import '../styles/home.css'
import '../styles/index.css'
import SettingsMenu from './SettingsMenu';
// import SearchBar from '../Components/SearchBar';
import Output from './Output';
import MusicPlayer from '../MusicPlayer/Musicplayer';
// import MyPlaylist from '../Components/MyPlaylist';
import Albums from '../Components/Albums';
// import { Provider } from 'react-redux';
// import store from '../Store/Store';
// import Output from './Output';
// import { Link } from 'react-router-dom';
import Nav from 'react-bootstrap/Nav';
import { Col, Dropdown, DropdownButton, Form, Row} from 'react-bootstrap';
// import { useSelector } from 'react-redux';

import axios from "axios";
import "../styles/search.css";

class SearchElement extends Component {
  state = {
    data: [],
    searchTerm: "", // New state to hold the search term
    index:[],
  };

  componentDidMount() {
    axios
      .get("http://localhost:8080/songs")
      .then(response => {
        this.setState({ data: response.data });
      })
      .catch(error => {
        console.log(error);
      });
  }

  // Function to handle changes in the search input
  handleSearchChange = event => {
    const { value } = event.target;
    this.setState({ searchTerm: value });
  };
  changeSong =(val)=>{
    this.index=val;
    console.log(this.index)
    // alert(this.index)
  }

  render() {
    const { data, searchTerm } = this.state;
    // Filter the recipes based on the search term
    const filteredRecipes = data.filter(user =>
      user.songname.toLowerCase().includes(searchTerm.toLowerCase())
    );
    return (
      <>
        <br />
        <br />
        <br />
        <br />
        {/* Add the search input */}
        <div className="search-container">
        <Row >
          <Col sm={38}>
            <Form  id="searchbar" className="d-flex flex-row">
              <Form.Control
                type="search"
                id="search"
                className="me-1"
                aria-label="Search"
                // value={searchQuery}
                // onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for Songs here"
            value={searchTerm}
            onChange={this.handleSearchChange}
              />
            </Form>
          </Col>
        </Row>
        </div>
        <div className="showans">
          <div></div>
          {filteredRecipes.map((user, index) => (
            <div className="div"  key={user.songname}>
              <div className="lab1">
                <h1 className="tabcon" onClick={this.changeSong(user[user.song_id])}>{user.songname}</h1>
              </div>
              {/* <img
                src={user.imageurl}
                alt="recipe"
                width="192"
                height="262"
                style={{ borderRadius: "50%" }}
              /> */}
            </div>
          ))}
        </div>
      </>
    );
  }
}

const MyPlaylist = () => {
   
    return (
        <>
            {/* <NavBar userData={userData}/> */}
            <div className="container">
                <h1 >Your Songs</h1>
                <article className="section">
                    {/* <SearchResults search={search} searchResults={searchResults} onAdd={doThese} />
                    <PlayList playListTracks={playListTracks} playListName={playListName} onNameChange={updatePlayListname} onRemove={removeTrack} onSave={savePlayList} /> */}
                </article>
                
      <SearchElement/>

            </div>
        </>
    )
}
function Avatar() {
  // var IsLoggedIn = useSelector((state) => state.isLoggedIn);
  return (
    <>
    <div>
       <img
            src="https://mdbootstrap.com/img/Photos/Avatars/img (31).jpg"
            className="rounded-circle"
            height="60"
            alt=""
            loading="lazy"
            />
    </div>
            <SettingsMenu/>
            </>
  )
}
// className="bg-body-tertiary"
export class Home extends Component {
  constructor( ) {
    super( );
    this.state = {  
      id : '1'
    };
this.changePlaylist = this.changePlaylist.bind(this);
this.changeAlbum = this.changeAlbum.bind(this);
this.changeSearch = this.changeSearch.bind(this);
this.changeHome = this.changeHome.bind(this);
} 

changeHome(e){
  e.preventDefault();
  this.setState({id : '1'})
}
changeSearch(e){
  e.preventDefault();
  this.setState({id : '2'})
}
changePlaylist(e){
  e.preventDefault();
  this.setState({id : '3'})
}
changeAlbum(e){
  e.preventDefault();
  this.setState({id : '4'})
}
render() {
    return (
      <>
<div>
<div class="bg">
    <Navbar expand="lg" className="bg-body-tertiary" >
    <Container fluid className="topnav">
        <Navbar.Brand >Music App</Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />

  <Navbar.Collapse id="navbarScroll">
            <Nav
            vertical
              className="me-auto my-2 my-lg-0"
              style={{ maxHeight: '200px' }}
              navbarScroll
            >
            <ul>
            <li className='dropdown'>
              <Dropdown>
                <DropdownButton id="dropdown-basic-button" title="Artists">
                  <Dropdown.Item href="/anilist">Anirudh Ravichander</Dropdown.Item>
                  <Dropdown.Item href="/aadhilist">Hiphop Tamizha</Dropdown.Item>
                  <Dropdown.Item href="/beiberlist">Justin Bieber</Dropdown.Item>
                  <Dropdown.Item href="/selenalist">Selena Gomez</Dropdown.Item>
                  <Dropdown.Item href="/arianalist">Ariana Grande</Dropdown.Item>
                  <Dropdown.Item href="/dualist">Dua Lipa</Dropdown.Item>
                </DropdownButton>  
                {/* <Dropdown.Menu> 
                </Dropdown.Menu> */}
              </Dropdown>
            </li>
              <li><Nav.Link onClick={this.changePlaylist}>
                My Songs 
              </Nav.Link></li>
              <li><Nav.Link onClick={this.changeAlbum}>
              Albums</Nav.Link></li>
              <li><Nav.Link href='/' onClick={this.changeHome}>Home</Nav.Link></li>
              </ul>
              </Nav>
              {/* <div className="col my-1 my-lg-0"> */}
              {/* </div>   */}
          </Navbar.Collapse>
      
      </Container>
      <Avatar/>
      <div>
      </div>
     </Navbar> 
     <div className='output'>
     { this.state.id==='2'? <Output/>:""}
     { this.state.id==='3'? <MyPlaylist/>:""}
     { this.state.id==='4'? <Albums/>:""}
     </div>
      
     { this.state.id==='1'? <MusicPlayer/>:""}
    </div> 
</div>
  
      </>
    )
}
}
export default Home;
