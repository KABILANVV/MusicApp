import {React} from 'react';
import { Dropdown,DropdownButton } from 'react-bootstrap';
import { useSelector } from 'react-redux';
// import { Link } from 'react-router-dom';

// class SettingsMenu extends React.Component {
//   constructor() {
//     super();
//     this.deleteAccount = this.deleteAccount.bind(this);
//     this.logout = this.logout.bind(this);
//   }

//   deleteAccount(e) {
//     console.log("Deleting Account")
//   }

//   logout(e) {
//     console.log("Logging out")
//   }

//   render() {
//     return (
  //     );
  //   }
  // }
  
  // export default SettingsMenu;
  
  const SettingsMenu = ()=> {
    const username = useSelector((state) => state.username);
      return(
              <Dropdown>
              <DropdownButton id="dropdown-basic-button"  title={username}>
                <Dropdown.Item >{username}</Dropdown.Item>
                <Dropdown.Item >Edit Profile</Dropdown.Item>
                <Dropdown.Item Link href='login' >Logout</Dropdown.Item>
                </DropdownButton>
              </Dropdown>
    )
}

export default SettingsMenu