import React, { useState } from 'react';
// import {  useSelector } from 'react-redux';
import { useDispatch  } from 'react-redux';
// import { login } from '../Actions/actions';
import axios from 'axios'
import '../styles/login.css'
import { Form, Row } from 'react-bootstrap';
// import { Link } from 'react-router-dom';
import { Link, useNavigate } from 'react-router-dom';
import { loginSuccess } from '../Actions/actions';
// import App from '../Sample/app';

const LoginPage = () => {
  const dispatch = useDispatch();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  // const IsLoggedIn = useSelector((state) => state.isLoggedIn);
  const navigate=useNavigate()
  const handleSubmit = async(e) => {
    e.preventDefault();
    // Call the login action with the entered credentials
      // const data = {
      //   username:username,
      //   password:password
      // }
      console.log(email+" "+password);
      // axios.post("",data);
      try{
        const response = await axios.post('http://localhost:8081/api/v1/auth/authenticate', { email, password });
        dispatch(loginSuccess(email.substring(0,email.length-10)));
      console.log(response)
      alert("Login Successful")
      navigate('/');
    }
    catch(e){
      alert("Invalid Credentials")
      navigate('/login');
      }
      // const token = response.data.token;
      // alert(IsLoggedIn)
  }
  return (
    <div className='loginbody'>
    <div className='form-div'>
    {/* <center> */}

    <Form className='wrapper' onSubmit={handleSubmit} >
    <br/>
      <Form.Group controlId="formGridlabel" id="heading" className="col col-sm-8 "><h1 id="h1">Login</h1></Form.Group>
      <br/>
      <br/>
      
      <Form.Group className="col col-sm-10">

      <Form.Label className='label'>Email</Form.Label>
      <br/>
      <br/>
        <Row className='group'>
      <Form.Control
        type="text"
        name="email"
        onChange={(e)=>setEmail(e.target.value)}
        placeholder="Email"
        value={email}
        className='input'
        required
      />
        </Row>
      <br/>
      <br/>
      <Form.Label className='label'>Password</Form.Label>
      <br/>
      <br/>
    <Row className='group'>
      <Form.Control
        type="password"
        name="password"
        value={password}
        onChange={(e)=>setPassword(e.target.value)}
        placeholder="Password"
        className='input'
        required
      />
        </Row>
      <button type='submit' className='btn btn-secondary' style={{marginLeft:"3.5cm"}}>Login</button>
      <h2 style={{marginRight:"3cm"}}>Don't have an Account?{"  "}<Link to='/signup' style={{textDecoration:"none"}}>SignUp</Link> here.</h2>
      <br/>
      </Form.Group>
    </Form>
      
        <span className='footer'></span>
    {/* </center> */}
    </div>    
    </div>    
  );
};


export default LoginPage;
