import React, { useState } from 'react';
import { Link,useNavigate } from 'react-router-dom';
// import Login from './login';
import axios from 'axios';

import '../styles/form.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Form, Row,InputGroup, Button } from 'react-bootstrap';

function Forms() {
    const[name,setName]=useState('')
    const[Username,setUsername]=useState('')
    const[Email,setEmail]=useState('')
    const[Mobile,setMobile]=useState('')
    const[Password,setPassword]=useState('')
    const[ConfirmPassword,setConfirmPassword]=useState('')
    const[dob,setDob]=useState('')
    const[Error,setError]=useState(false)

    function isFirstFunctionTrue() {
        // Replace this condition with your own logic
        // For example, you might check if some input is valid or if a certain condition is met
        if(name.length===0 || Username.length===0||Email.length===0){
            setError(true);
            return false;
        }
        if(Mobile.length!==10){
            setError(true);
            return false;
        }
        if(Password!==ConfirmPassword){
            setError(true);
            return false;
        }
        if(Username&&Email){
            console.log(Username,Email,Mobile,Password,Error);
        }
        return true;
      }
      const navigate=useNavigate()
      function checkAndCall(e) {
        e.preventDefault();
        if (isFirstFunctionTrue()) {
            if(!Email.includes('@gmail.com')){
                    setEmail(Email+"@gmail.com");
            }
        const data = {
            user:{
            username:Username,
            password:Password
            },
            name:name,
            email:Email,
            phone:Mobile,
            dob: dob,
          };
        axios.post('http://localhost:8080/add', data);
        const user = {
            name:Username,
            password:Password,
            email:Email
          };
          axios.post('http://localhost:8081/api/v1/auth/register', user);
          navigate('/login');
        }
      }
      const handleSubmit = (e)=>{
        checkAndCall(e);
      }
  return (
    <div className='formbody'>
    <div class="Registration">
    <Form className="form" onSubmit={handleSubmit} >
        <div>
        <Form.Group controlId="formGridlabel" id="reg-head" className="col col-sm-20"><h1>Register Here</h1></Form.Group>
        <br/>
        <Row className="mb-3">
        <Form.Group controlId="formBasicEmail" className="col col-sm-10">
            <Form.Label className='input'>Name</Form.Label>
            <Form.Control placeholder='Name' onChange={e=>setName(e.target.value)}/>
        {Error && name.length<=0?
        <Form.Label className='error'>*Name is Required </Form.Label>:""}
            </Form.Group>   
    </Row>
        <Row className="mb-3">
        <Form.Group controlId="formBasicEmail" className="col col-sm-10">
            <Form.Label className='input'>Username</Form.Label>
            <Form.Control placeholder='Username' onChange={e=>setUsername(e.target.value)}/>
        {Error && Username.length<=0?
        <Form.Label className='error'>*Username is Required </Form.Label>:""}
            </Form.Group>   
    </Row>
        <Row className="mb-3">
        <Form.Group controlId="formBasicEmail" className="col col-sm-10">
            <Form.Label className='input'>Email</Form.Label>
            <InputGroup>
        <Form.Control placeholder='Email' onChange={e=>setEmail(e.target.value)} /><InputGroup.Text id="basic-addon2">@gmail.com</InputGroup.Text>
            </InputGroup>
        {Error && Email.length<=0?
        <label className='error'>*Email is Required</label>:""}
            </Form.Group>
        </Row>
        
        <Row className="mb-3">
        <Form.Group controlId="formBasicMobile" className="col col-sm-10">
            <Form.Label className='input'>Date Of Birth</Form.Label>
            <InputGroup>
            <Form.Control placeholder='Date Of Birth' onChange={e=>setDob(e.target.value)}/>
            </InputGroup>
            {Error && dob.length<=0?
        <Form.Label className='error'>*Date of Birth is Required </Form.Label>:""}
        </Form.Group>
        </Row>
        <Row className="mb-3">
        <Form.Group controlId="formBasicMobile" className="col col-sm-10">
            <Form.Label className='input'>Mobile Number</Form.Label>
            <InputGroup>
                <InputGroup.Text id="basic-addon2">+91</InputGroup.Text>
            <Form.Control placeholder='Mobile Number' onChange={e=>setMobile(e.target.value)}/>
            </InputGroup>
        {Error && Mobile.length<=4?
        <Form.Label className='error'>*Mobile Number is Required</Form.Label>:""}
        </Form.Group>
        </Row>
        
        <Form.Label className='input'>Password</Form.Label>
        <Row className="mb-3">
        <Form.Group controlId="formBasicEmail" className="col col-sm-10">
            <Form.Control placeholder='Password' onChange={e=>setPassword(e.target.value)}/>
        {Error && Password.length<=3 && Password.length!==0?
        <Form.Label className='error'>Password is short </Form.Label>:""}
        {Error && Password.length===0?
        <Form.Label className='error'>*Password is Required </Form.Label>:""}
        </Form.Group>
        </Row>
        

        <Row className="mb-3">
        <Form.Group controlId="formBasicEmail" className="col col-sm-10">
            <Form.Label className='input'>Confirm Password</Form.Label>
            <Form.Control placeholder='Re-Enter Password' onChange={e=>setConfirmPassword(e.target.value)}/>
        {Error && ConfirmPassword!==Password?
        <Form.Label className='error'>Password Doesn't Match </Form.Label>:""}
        {Error && ConfirmPassword===""?
        <Form.Label className='error'>{"\n"}*Confirm Password is Required</Form.Label>:""}
      <br/>
      <br/>
        </Form.Group>
           <button id="button" className="btn btn btn-lg" type='submit'>Submit</button>
     <h5>Already have an Account?..<Link to='/login' style={{textDecoration:'none'}}><Button style={{background:'transparent',width:'2cm',color:'black'}}>Login</Button></Link>here!</h5>
        </Row>
        </div>

      
     </Form>
     
      <br/>
      <br/>
      <br/>
     </div>
     </div>
  )
}

export default Forms